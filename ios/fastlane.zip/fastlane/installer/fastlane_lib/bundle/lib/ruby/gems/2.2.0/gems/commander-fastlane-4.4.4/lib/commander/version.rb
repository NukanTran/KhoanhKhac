module Commander
  VERSION = '4.4.4'.freeze
end
