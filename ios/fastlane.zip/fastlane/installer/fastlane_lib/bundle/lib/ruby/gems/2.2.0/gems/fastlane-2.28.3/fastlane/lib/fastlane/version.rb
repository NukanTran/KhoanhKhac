module Fastlane
  VERSION = '2.28.3'.freeze
  DESCRIPTION = "The easiest way to automate beta deployments and releases for your iOS and Android apps".freeze
end
