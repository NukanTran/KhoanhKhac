# coding: utf-8

require 'tty/screen'
