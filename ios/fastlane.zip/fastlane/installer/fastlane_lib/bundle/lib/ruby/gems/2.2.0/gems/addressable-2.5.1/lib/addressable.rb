require 'addressable/uri'
require 'addressable/template'
