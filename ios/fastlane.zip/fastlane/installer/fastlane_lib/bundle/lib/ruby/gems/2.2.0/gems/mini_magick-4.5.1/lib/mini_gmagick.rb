require 'mini_magick'

MiniMagick.processor = :gm
