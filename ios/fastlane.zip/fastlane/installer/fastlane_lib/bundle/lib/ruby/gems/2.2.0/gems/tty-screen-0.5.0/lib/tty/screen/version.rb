# coding: utf-8

module TTY
  class Screen
    VERSION = "0.5.0"
  end # Screen
end # TTY
