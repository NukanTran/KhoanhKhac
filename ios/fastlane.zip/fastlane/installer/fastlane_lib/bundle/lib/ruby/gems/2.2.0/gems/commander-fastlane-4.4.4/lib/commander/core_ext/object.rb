class Object
  ##
  # Return the current binding.

  def get_binding
    binding
  end
end
